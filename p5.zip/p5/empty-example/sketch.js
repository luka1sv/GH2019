var mapp;
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}
function del_from_map(x,y){
    background(135,206,250);
    fill(139,69,19);
    rect(0,96,1024,672);
    mapp[y][x] = 0
}
function setup() {
    trava = loadImage("tileset/trava.png");
    dirt = loadImage("tileset/dirt.png");
    createCanvas(1024,768);
    background(135,206,250);
    fill(139,69,19);
    rect(0,96,1024,672);
    startx = getRandomInt(1,31);
    starty = getRandomInt(5,23);
    mapp = spawnmap();
    del_from_map(startx,starty);
}
function draw() {
    print(mapp);
    for (var i = 3;i<24;i++) {
        for (var k = 0; k < 32; k++) {
            if  (mapp[i][k] != 0) {
                mapp[i][k].show()
            }
        }
    }
}
function keyPressed() {
    console.log(keyCode);
    if (keyCode === 87){
        console.log('kek');
    }
}
function spawnmap() {
    var map = [];
    for (var i =0;i<768;i+=32){
        map.push([]);
        if (i < 96) {
            for (var k = 0; k < 1024; k+=32) {
                map[i/32].push(0)
            }
        }
        else if( i == 96 ){
            for (var k = 0; k < 1024; k+=32) {
                map[i/32].push(new block(true,k,i))
            }
        }
        else {
            for (var k = 0; k < 1024; k+=32) {
                map[i/32].push(new block(false,k,i))
            }
        }
    }
    return map
}
class block {
    constructor(withgr=false,x,y) {
        this.withgr = withgr;
        this.x = x;
        this.y = y;
    }
    show() {
        if (this.withgr) {
            image(trava,this.x,this.y)
        }
        else {
            image(dirt,this.x,this.y)
        }
    }
}